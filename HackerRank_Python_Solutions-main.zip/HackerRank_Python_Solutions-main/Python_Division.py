if __name__ == '__main__':
    a = int(input())
    b = int(input())
    int_result = int(a/b)
    float_result = a/b
    print(int_result)
    print(float_result)
