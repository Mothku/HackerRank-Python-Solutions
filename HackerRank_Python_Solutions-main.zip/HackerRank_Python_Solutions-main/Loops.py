if __name__ == '__main__':
    n = int(input())
    for i in range(n):# 0<= i<n
        result = i**2# we can do i*i also
        print(result)
