x , k = map(int , input("").split(' '))
m = eval(input(""))
print("{}".format('True' if k==m else 'False'))
