if __name__ == '__main__':
    a = int(input())
    b = int(input())
    addition = a+b
    subtraction = a-b
    multiplication = a*b
    print(addition)
    print(subtraction)
    print(multiplication)
