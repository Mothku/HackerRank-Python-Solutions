n=int(input(""))
s = set()
for i in range(n):
    m=input("")
    s.add(m)

print(len(s))
