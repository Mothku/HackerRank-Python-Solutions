a = int(input(""))
b = int(input(""))
print('{}\n{}\n{}'.format((a//b),(a%b),divmod(a,b)))
